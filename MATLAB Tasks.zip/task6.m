P_Spam = 0.4;
P_NotSpam = 0.6;
P_Free_given_Spam = 0.7;
P_Free_given_NotSpam = 0.1;
P_Spam_given_Free = (P_Free_given_Spam*P_Spam) / ...
    ((P_Free_given_Spam*P_Spam)+(P_Free_given_NotSpam*P_NotSpam))