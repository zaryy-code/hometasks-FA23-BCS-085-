data = randn(1,1000);    % 1000 random numbers (normal distribution)
histogram(data)