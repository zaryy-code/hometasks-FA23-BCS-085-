data = readtable('students.csv');
head(data, 5)