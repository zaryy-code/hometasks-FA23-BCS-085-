rand(1,5)
randn(1,5)
randi([1 100],1,5)