x = [10 20 30 40 50];
m=mean(x) %mean
v=var(x) %variance
fprintf('variance =%d\n', m)
fprintf('variance =%d\n', v)