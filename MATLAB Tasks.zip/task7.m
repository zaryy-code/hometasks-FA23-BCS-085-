n = 5; r = 2;
permutation = factorial(n)/factorial(n-r)
combination = factorial(n)/(factorial(r)*factorial(n-r))