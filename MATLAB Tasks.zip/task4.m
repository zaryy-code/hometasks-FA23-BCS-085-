 coin = randi([0 1],1,10);   % 0 = Head, 1 = Tail
disp(coin)